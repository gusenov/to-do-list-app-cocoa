//
//  TDLScroller.h
//  To-Do List App UI
//
//  Created by Abbas Gussenov on 2/4/16.
//  Copyright © 2016 Gussenov Lab. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TDLScroller : NSScroller

@end
