//
//  TDLTaskTitleField.h
//  To-Do List App UI
//
//  Created by Abbas Gussenov on 2/3/16.
//  Copyright © 2016 Gussenov Lab. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TDLTaskTitleField : NSTextField

@property BOOL editMode;

@end
