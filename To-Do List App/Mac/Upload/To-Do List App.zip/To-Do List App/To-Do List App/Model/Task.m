//
//  Task.m
//  To-Do List App
//
//  Created by Abbas Gussenov on 2/2/16.
//  Copyright © 2016 Gussenov Lab. All rights reserved.
//

#import "Task.h"

@implementation Task

// Insert code here to add functionality to your managed object subclass

@end
