//
//  PSBPanel.h
//  PopupInStatusBar
//
//  Created by Abbas on 12/5/15.
//  Copyright © 2015 Gussenov. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface PSBPanel : NSPanel

@end
