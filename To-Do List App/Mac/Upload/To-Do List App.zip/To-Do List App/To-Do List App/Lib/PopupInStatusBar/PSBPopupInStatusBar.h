//
//  PSBPopupInStatusBar.h
//  PopupInStatusBar
//
//  Created by Abbas on 1/7/16.
//  Copyright © 2016 Gussenov. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PSBPanelCtrl.h"

@interface PSBPopupInStatusBar : NSObject <PSBPanelCtrlDelegate>

- (id)initWithWindow:(PSBPanel *)aWindow;

@end
