//
//  PSBSearchTxtView.h
//  PopupInStatusBar
//
//  Created by Abbas on 1/18/16.
//  Copyright © 2016 Gussenov. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface PSBSearchTxtView : NSView

@property (strong) NSSearchField *searchField;
@property (strong) NSTextField *txtField;

@end
