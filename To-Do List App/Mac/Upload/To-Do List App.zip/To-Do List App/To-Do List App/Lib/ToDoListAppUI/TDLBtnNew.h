//
//  TDLBtnNew.h
//  To-Do List App UI
//
//  Created by Gussenov on 1/30/16.
//  Copyright © 2016 Gussenov. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TDLBtnNew : NSButton

@end
